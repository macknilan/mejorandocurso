//
//  NyanCat.m
//  demo_005_1
//
//  Created by Afrael Ortiz on 10/21/13.
//
//

#import "NyanCat.h"

@implementation NyanCat


-(void)changeState:(CharacterStates)newState
{
    self.gameObjectState = newState;
}

@end
