//
//  NyanCat.h
//  demo_005_1
//
//  Created by Afrael Ortiz on 10/21/13.
//
//

#import "GameObject.h"

@interface NyanCat : GameObject

@end
