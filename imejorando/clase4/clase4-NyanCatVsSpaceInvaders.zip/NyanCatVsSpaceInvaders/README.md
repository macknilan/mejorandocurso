![Mejorandola](http://miguelnieva.com/img/mejorandola-grande.png)


## Material Original de Cursos

- Te recomendamos siempre leer cada "README.md" en cada carpeta.
- Ubica tu curso y dentro de cada carpeta encontrarás todas las clases divididas por tema.
- Puedes dar un Fork al repositorio y estar actualizado siempre con GIT ó puedes descargar los .ZIP de cada curso, incluidos en su carpeta.

### Conceptos Avanzados de Programación de Juegos con Cocos2D

### Juego de Nyan Cat vs. Space Invaders